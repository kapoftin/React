import styled from 'styled-components'
import './zapal.scss'
import { NavLink } from 'react-router-dom'


const Zapol = () => {
  return(
    <div className='container'>
    <div className='border'>
        <div className='dvin'><div className='text'> Find a character by name:</div><div className='div_border'>enter name</div></div>
    </div>
    <div className='div-empty'></div>
    </div>
  )

}

export default Zapol;