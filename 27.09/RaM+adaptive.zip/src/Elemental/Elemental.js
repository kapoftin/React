// import styled from 'styled-components'


// export const Headers = styled.div`
//     display: flex;
//     justify-content: center;
//     flex-wrap: wrap;
//     margin-top: 40px;
//     `

// export const Div = styled.div`    
//         margin-right: 30px;
//         font-family: Roboto Condensed;
// font-size: 28px;
// font-weight: 700;
// line-height: 33px;
// letter-spacing: 0em;
// text-align: left;
// color: #1DC985;
// `

// export const Ots = styled.div`
//     display: flex;
//     justify-content: center;
//     flex-wrap: wrap;
//     width: 340px;
//     `
//     export const Border = styled.div`
//     display: flex;
//     justify-content: center;
//     flex-wrap: wrap;
//     margin-top: 60px;
//     `

// export const Divn = styled.div`
//         margin-right: 715px;
//         border-style: solid;
//         border-radius: 0.5px;
//         border-width: 1px;
//         width: 350px;
//         height: 150px;
//         border-color: black;
//         font-family: Roboto Condensed;
// font-size: 18px;
// font-weight: 700;
// line-height: 21px;
// letter-spacing: 0em;
// text-align: left;

//         div{
//             margin-top: 30px;
//         margin-left: 30px;
//         }
//         .div_border{
//             border-style: solid;
//         border-radius: 0.5px;
//         border-width: 0.5px;
//         margin-right: 60px;
//         font-family: 'Courier New', Courier, monospace;
//         }
// `
// export const Morty = styled.div`
// display: flex;
// justify-content: center;
// flex-direction: column;
// flex-wrap: wrap;
// align-items: center;
// font-family: Roboto Condensed;
// font-size: 22px;
// font-weight: 700;
// line-height: 26px;
// letter-spacing: 0em;
// text-align: center;
// margin-top: 60px;
// box-shadow: black;
// div{
//     margin-top: 40px;
// }

// `

// export const First = styled.div`
//     display: flex;
//     justify-content: center;
//     flex-wrap: wrap;
//     color: white;
//     gap: 90px;
//     margin-right: 110px;
//     img{
//         margin-top: 40px;
//     }
// `

// export const Color = styled.div`
//     background-color: #232222;
//     width: 260px;
//     height: 340px;
// `

