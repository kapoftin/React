import './green_txt.scss';

const Green_txt = () =>{
    return(
        <>
        <a className="green_txt">Cloverly API</a>
        </>
    )
}

export default Green_txt;