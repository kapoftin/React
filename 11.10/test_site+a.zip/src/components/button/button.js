import './button.scss';

const Button = () => {
    return (<div className='Button__knop'>
        <a className='Button__knop__txt' href='#'>Get Started</a>
    </div>
    )
}
export default Button;