import './foot.scss';
import Im1 from '../img/Frames.svg'
import Im2 from '../img/Framesg.svg'

const Foot = () => {
    return (
    <div className='container'>
        
        <div className='div_spec'>
            <img className='img1' src={Im2}></img>
            <img className='img2' src={Im1}></img>
            </div>   
        <div className='div'>
     
            <div className='div_foot1 div_ftex'>
                <div className='div_txt'><div className='div_nt'>Emission Calculations</div></div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
            </div>

            <div className='div_foot2 div_ft'>
                <div className='div_txt'><div className='div_nt'>Emission Calculations</div></div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
            </div>

            <div className='div_foot3 div_ft'>
                <div className='div_txt'><div className='div_nt'>Emission Calculations</div></div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
            </div>

            <div className='div_foot4 div_ft'>
                <div className='div_txt'><div className='div_nt'>Emission Calculations</div></div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
                <div className='div_txt'>Emission Calculations</div>
            </div>
        </div>
    </div>
    )
}
export default Foot;