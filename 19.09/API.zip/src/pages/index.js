import Slider from './slider/slider'
import AboutPage from './about/about'
import MarvelPage from './marvelPage/marvel'

export {Slider, AboutPage, MarvelPage}