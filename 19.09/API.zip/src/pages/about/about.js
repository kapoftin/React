import './about.scss'

const AboutPage = () => {
    
    return(
        <>
            <div class="morphing">
                <div className="word">Привет</div>
                <div className="word">я</div>
                <div className="word">другая</div>
                <div className="word">страница</div>
                <div className="word">Я</div>
                <div className="word">нахожусь</div>
                <div className="word">тут "./pages/about/about.js"</div>
            </div>
        </>
    )
}

export default AboutPage;